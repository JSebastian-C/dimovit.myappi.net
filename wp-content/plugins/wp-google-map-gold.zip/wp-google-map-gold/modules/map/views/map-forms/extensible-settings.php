<?php
$extensibleSettings = '';
$markup = apply_filters('wpgmp_add_MoreSettings',$extensibleSettings);
echo $markup;
?>
