<?php
/**
 * Plugin Name: Custom Code Kool
 * Plugin URI: https://www.koolmarketing.net
 * Description: Custom code.
 * Version: 1.0
 * Author: Daniel
 * Author URI: none
 */
 error_reporting(0);
// TLD Prices  

 function change_whois_result( $whois_result ) {
    if ( in_array( $whois_result->tld, array( 'com', 'net', 'com.co', 'org' ) ) ) {
        $product = wc_get_product( '3381' );
        $price = $product->get_price();
        $month_price = number_format($price/12);
        $whois_result->price = '$'.$month_price.'/mes'; //->tld, ->domain
        $whois_result->link = "/?add-to-cart=3381&domain=[domain]&tld=[tld]&price='$price'";
    }else if(in_array( $whois_result->tld, array( 'co' ))){
        $product = wc_get_product( '3683' );
        $price = $product->get_price();
        $month_price = number_format($price/12);
        $whois_result->price = '$'.$month_price.'/mes'; //->tld, ->domain
        $whois_result->link = "/?add-to-cart=3683&domain=[domain]&tld=[tld]&price='$price'";
    }else if(in_array( $whois_result->tld, array( 'company' ))){
        $product = wc_get_product( '3684' );
        $price = $product->get_price();
        $month_price = number_format($price/12);
        $whois_result->price = '$'.$month_price.'/mes'; //->tld, ->domain
        $whois_result->link = "/?add-to-cart=3684&domain=[domain]&tld=[tld]&price='$price'";
    }else if(in_array( $whois_result->tld, array( 'coach' ))){
        $product = wc_get_product( '3685' );
        $price = $product->get_price();
        $month_price = number_format($price/12);
        $whois_result->price = '$'.$month_price.'/mes'; //->tld, ->domain
        $whois_result->link = "/?add-to-cart=3685&domain=[domain]&tld=[tld]&price='$price'";
    }else if(in_array( $whois_result->tld, array( 'academy', 'care' ))){
        $product = wc_get_product( '3686' );
        $price = $product->get_price();
        $month_price = number_format($price/12);
        $whois_result->price = '$'.$month_price.'/mes'; //->tld, ->domain
        $whois_result->link = "/?add-to-cart=3686&domain=[domain]&tld=[tld]&price='$price'";
    }else if(in_array( $whois_result->tld, array( 'yoga' ))){
        $product = wc_get_product( '3687' );
        $price = $product->get_price();
        $month_price = number_format($price/12);
        $whois_result->price = '$'.$month_price.'/mes'; //->tld, ->domain
        $whois_result->link = "/?add-to-cart=3687&domain=[domain]&tld=[tld]&price='$price'";
    }else if(in_array( $whois_result->tld, array( 'menu' ))){
        $product = wc_get_product( '3688' );
        $price = $product->get_price();
        $month_price = number_format($price/12);
        $whois_result->price = '$'.$month_price.'/mes'; //->tld, ->domain
        $whois_result->link = "/?add-to-cart=3688&domain=[domain]&tld=[tld]&price='$price'";
    }else if(in_array( $whois_result->tld, array( 'club' ))){
        $product = wc_get_product( '3689' );
        $price = $product->get_price();
        $month_price = number_format($price/12);
        $whois_result->price = '$'.$month_price.'/mes'; //->tld, ->domain
        $whois_result->link = "/?add-to-cart=3689&domain=[domain]&tld=[tld]&price='$price'";
    }
    return $whois_result;
}
add_filter( 'wp24_domaincheck_whois_result', 'change_whois_result' );


// Compra de dominio

// Add custom note as custom cart item data
add_filter( 'woocommerce_add_cart_item_data', 'get_custom_product_note', 30, 2 );
function get_custom_product_note( $cart_item_data, $product_id ){
    if ( isset($_GET['domain']) && ! empty($_GET['domain']) ) {
        $cart_item_data['custom_note'] = sanitize_text_field( $_GET['domain'].".".$_GET['tld'] );
        $cart_item_data['unique_key'] = md5( microtime().rand() );
    }
    return $cart_item_data;
}


// Display note in cart and checkout pages as cart item data - Optional
add_filter( 'woocommerce_get_item_data', 'display_custom_item_data', 10, 2 );
function display_custom_item_data( $cart_item_data, $cart_item ) {
    if ( isset( $cart_item['custom_note'] ) ){
        $cart_item_data[] = array(
            'name' => "Dominio",
            'value' =>   $cart_item['custom_note'],
        );
    }
    return $cart_item_data;
}

// Save and display product note in orders and email notifications (everywhere)
add_action( 'woocommerce_checkout_create_order_line_item', 'add_custom_note_order_item_meta', 20, 4 );
function add_custom_note_order_item_meta( $item, $cart_item_key, $values, $order ) {
    if ( isset( $values['custom_note'] ) ){
        $item->update_meta_data( 'Dominio',  $values['custom_note'] );
    }
}


// function compra_dominio( $cart_object ) {
//     global $woocommerce;
    
//     if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 ){
//         return;
//     }
    
//     if(isset($_GET['domain']) && isset($_GET['price'])){
//      foreach ($woocommerce->cart->get_cart() as $cart_item_key => $cart_item) {
//         if(has_term('Dominios', 'product_cat',$cart_item['data']->id)){
//         $cart_item['data']->set_price($_GET['price']*12); //Actualiza el precio
//             }
//         }   
//     }
// }
// add_action('woocommerce_before_calculate_totals', 'compra_dominio');

// Desactivar pestaña descargas de Mi Cuenta
add_filter( 'woocommerce_account_menu_items', 'custom_remove_downloads_my_account', 999 );
 
function custom_remove_downloads_my_account( $items ) {
unset($items['downloads']);
return $items;
}